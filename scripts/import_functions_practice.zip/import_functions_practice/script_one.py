from area_functions.areas import area_square, area_circle

print()
print("Area of square:", area_square(5, 5))
print("Area of circle:", area_circle(5))
print()

input("What is your favoite shape?")

if ("Square"):
    print("That shape has four sides!")

elif("Circle"):
    print("That only has one side!")

else:
    print("I don't know that shape.")