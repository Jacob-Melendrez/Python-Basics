import math 

def area_square(l,w): 
    return l * w 

def area_circle(radius):
    return math.pi * radius * 2 